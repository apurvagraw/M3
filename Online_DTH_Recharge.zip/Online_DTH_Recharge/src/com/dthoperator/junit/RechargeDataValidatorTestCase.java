package com.dthoperator.junit;											// NAME OF PACKAGE

import static org.junit.Assert.*;																
import org.junit.Test;													// NECESSARY IMPORTS 		
import com.dthoperator.bean.*;
import com.dthoperator.service.*;

public class RechargeDataValidatorTestCase {							// CLASS RECHARGEDATAVALIDATORTESTCASE
	
	RechargeDataValidator RdV = new RechargeDataValidator();								// CREATING THE OBJECT
	RechargeDetails tdata1= new RechargeDetails("Airtel","1089343456","monthly",210,4667);
	RechargeDetails tdata2= new RechargeDetails("DishTV","4089343434","yearly",1260,4367);	// ENTERING THE DATA
	RechargeDetails tdata3= new RechargeDetails("Reliance","5089343422","monthly",220,4557);
	RechargeDetails tdata4= new RechargeDetails("TATASky","6089343433","quaterly",500,4167);
	
	public void testValidateDetails() {														// METHOD TO CHECK THE ENTERED DATA
		assertEquals(true,RdV.validateDetails(tdata1));
	}
	
	
	public void testValidateDetails2() {													// METHOD TO CHECK THE ENTERED DATA
		assertEquals(false,RdV.validateDetails(tdata2));
	}
	
	
	public void testValidateDetails3() {
		assertEquals(false,RdV.validateDetails(tdata3));									// METHOD TO CHECK THE ENTERED DATA
	}
	
	
	public void testValidatedthOperator() { 											    //METHOD TO CHECK THE ENETERED DATA 
		assertEquals(true,RdV.validatedthOperator(tdata1));
	}
	
	
	public void testValidatedthOperator2() {												// METHOD TO CHECK THE ENTERED DATA
		assertEquals(false,RdV.validatedthOperator(tdata4));
	}

}


