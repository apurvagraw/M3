package com.dthoperator.junit;


import static org.junit.Assert.*;

//import org.junit.Test;
import org.junit.*;

import com.dthoperator.bean.*;
import com.dthoperator.service.*;
import com.dthoperator.exception.*;


public class RechargeCollectionHelperTestCase {
	static RechargeDetails item=null;
	static RechargeCollectionHelper collection_helper;
	

	@Test
	public void test() {	
	//collection_helper.adddetails(item);
	Assert.assertNotNull(collection_helper);
	System.out.print(collection_helper);
	}
	@Before 
	public void beforeclass()
	{
		collection_helper= new RechargeCollectionHelper();
		item = new RechargeDetails("DishTV","4089343434","yearly",1260,4367);
		//item = null;
	}
	
	
	@After
	public void afterclass()
	{
		item=null;
		collection_helper=null;
	}
	
	
}