package com.dthoperator.exception;

public class InvalidNumberException extends Exception {           		// METHOD TO RAISE THE EXCEPTION OF INVALID NUMBER
	public InvalidNumberException() {
		System.out.println("You have entered an invalid number");   		// THROWS AN EXCEPTION

	}
}
