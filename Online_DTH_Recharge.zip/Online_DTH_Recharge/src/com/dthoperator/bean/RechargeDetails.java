package com.dthoperator.bean;

import java.util.Random;
import java.io.Serializable;                               // NECESSARY IMPORTS	

public class RechargeDetails implements Serializable{      // RECHARGE DETAILS CLASS IMPLEMENTING SERIALIZABLE
	String dthOperator;                                   
	String consumerNo;                                
	String rechargePlan;                                       // INSERTING THE MANDATORY DETAILS ABOUT THE RECHARGE
	int amount;
	int Transaction_ID;

	public RechargeDetails() {                                // CONSTRUCTOR OF CLASS RECHARGEDETAILS
		this.Transaction_ID = (int)(Math.random()*9000)+1000;  // GENERATING THE RANDOM TRANSACTION ID 
	}
	public String getdthOperator() {                        // METHOD TO ASK THE RECHARGE TYPE
		return dthOperator;
	}
	public void setdthOperator(String dthOperator) {       // METHOD TO SET THE RECHARGE TYPE
		this.dthOperator = dthOperator;
	}
	public String getconsumerNo() {                     // METHOD TO ASK THE OPERATOR NAME
		return consumerNo;
	}
	public void setconsumerNo(String consumerNo) {  // METHOD TO SET THE OPERATOR NAME
		this.consumerNo = consumerNo;
	}
	public String getrechargePlan() {                             // METHOD TO ASK THE MOBILE NUMBER	
		return rechargePlan;
	}
	public void setrechargePlan(String rechargePlan) {                // METHOD TO GET THE MOBILE NUMBER 
		this.rechargePlan = rechargePlan;
	}
	public double getAmount() {                              // METHOD TO ASK THE AMOUNT OF RECHARGE
		return amount;
	}
	public void setAmount(int amount) {                  // METHOD TO GET THE AMOUNT OF RECHARGE
		this.amount = amount;
	}
	public int getTransaction_ID() {    						// METHOD TO GET THE TRANSACTION ID
		return Transaction_ID;
	}
	
	public RechargeDetails(String dthOperator, String consumerNo, String rechargePlan, int amount,
			int Transaction_ID) {                   // METHOD TO ASSIGN THE DETAILS TO DIFFERENT MANDATORY FIELDS INSIDE THE CLASS
		super();
		this.dthOperator = dthOperator;
		this.consumerNo = consumerNo;
		this.rechargePlan = rechargePlan;                   // ASSIGNING VALUES TO MANDATORY FIELDS   
		this.amount = amount;
		this.Transaction_ID = Transaction_ID;
	}
	public String toString() {                          // METHOD TO SHOW THE OUTPUT DETAILS ON THE DISPLAY SCREEN
		return "RechargeDetails [dthOperator=" + dthOperator + ", consumerNo=" + consumerNo + ", rechargePlan="
				+ rechargePlan + ", amount=" + amount + ", Transaction_ID=" + Transaction_ID + "]";
	}
	
}
