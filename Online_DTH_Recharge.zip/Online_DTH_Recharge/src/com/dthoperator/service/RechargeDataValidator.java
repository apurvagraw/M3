package com.dthoperator.service;

import com.dthoperator.bean.*;				// NECESSARY IMPORTS	

public class RechargeDataValidator {								// CLASS RECHARGEDATAVALIDATOR

	public boolean validateDetails(RechargeDetails PrU)				// METHOD TO VALIDATE THE DATA ENTERED BY THE USER AT RUNTIME
	{
		if(validatedthOperator(PrU) && validateConsumerNo(PrU) && validaterechargePlan(PrU) && validateAmount(PrU) && validateTransaction_ID(PrU))
		{
			return true;
			
		}
		else
		{
			return false;
		}
	}
	private boolean validateTransaction_ID(RechargeDetails PrU) 		// METHOD TO VALIDATE THE TRANSACTION ID 
	{
		String Transaction_ID= Integer.toString(PrU.getTransaction_ID()); 		
		if(Transaction_ID.matches("[0-9]{4}")) {
			return true;
		}else {
			return false;
		}
		
	}
	private boolean validateAmount(RechargeDetails PrU)				// METHOD TO VALIDATE THE AMOUNT ENETERED BY THE USER
	{
		double amount=PrU.getAmount();
		try {
			if(amount>=10 && amount<=9999)
			{
				return true;
			}
			else
			{
				return false;
			}
		}catch(NumberFormatException NfE) {							// EXCEPTION HANDLING
			System.out.println("Please Enter currect amount");
			return false;
		}
	}
	private boolean validaterechargePlan(RechargeDetails PrU)	// METHOD TO VALIDATE THE RECHARGE PLAN ENTERED BY THE USER
	{
		String x = PrU.getrechargePlan().toLowerCase();
		String y = PrU.getrechargePlan().toLowerCase();			// ACCEPTING THE RECHARGE PLAN IN LOWER CASES
		String z = PrU.getrechargePlan().toLowerCase();
		String a = PrU.getrechargePlan().toLowerCase();
		if(x.equals("monthly") ||  y.equals("quaterly") || z.equals("half yearly")|| a.equals("annual"))
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
	private boolean validateConsumerNo(RechargeDetails PrU) 			// METHOD TO VALIDATE THE CONSUMER NO
	{
		String ConsumerNo=PrU.getconsumerNo();
		if(ConsumerNo.matches("[7-9][0-9]{9}"))
		{
			return true;
		}
		else
		{  
			return false;
		}
	}
	public boolean validatedthOperator(RechargeDetails PrU)		 
	{
		String x = PrU.getrechargePlan().toLowerCase();
		String y = PrU.getrechargePlan().toLowerCase();			// METHOD TO VALIDATE THE DTH OPERATOR TYPE
		String z = PrU.getrechargePlan().toLowerCase();
		String a = PrU.getrechargePlan().toLowerCase();
		if(x.equals("airtel") ||  y.equals("dishTV") || z.equals(" reliance")|| a.equals("tatasky"))
		{
			return true;
		}
		else  
		{
			return false;
		}
	}

}
