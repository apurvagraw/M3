package com.dthoperator.ui;

import java.security.Provider.Service;                        
import java.util.Scanner;

import com.dthoperator.bean.*;
import com.dthoperator.exception.*;      // NECESSARY IMPORTS 
import com.dthoperator.service.*;


public class RechargeClient {                                          // CLASS RECHARGECLIENT
	Scanner scanner = new Scanner(System.in);
	RechargeDetails obj=new RechargeDetails();                          
	RechargeDataValidator RdV=new RechargeDataValidator();            // CREATING THE DIFFERENT OBJECTS OF VARIOUS CLASSES 
	RechargeCollectionHelper RfH = new RechargeCollectionHelper();                      
	public static void main(String[] args) {
		RechargeClient rc = new RechargeClient();
		try {                                                         // EXCEPTION HANDLING
			rc.displayMenu();                                 
		} catch (InvalidNumberException e) {
			
			
		}
	}
	public void displayMenu() throws InvalidNumberException                   // METHOD TO CREATE THE MAIN MENU 
	{
		System.out.println("1.Make a Recharge");
		System.out.println("2.Display Recharge Details");
		System.out.println("3.Exit");
		int option;
		try{                                                        // EXCEPTION HANDLING
			option=Integer.parseInt(scanner.nextLine());
		}catch(NumberFormatException nfe){
			throw new InvalidNumberException();
		}
		switch(option)                                            // SWITCH AND ITS CASES TO DISPLAY THE MENU AND HANDLING EXCEPTIONS
		{
		case 1:
			recharge();
			displayMenu();
			break;
		case 2:
			RechargeCollectionHelper.display_rec();
			displayMenu();
			break;
		case 3:
			System.out.println("You Have Successfully Closed The Application");
			System.exit(0);
			break;
		default:
			throw new InvalidNumberException();
			
		}
	}

	private void recharge() 										// METHOD TO ENTER THE DEATILS OF THE RECHARGE
	{
			
			System.out.println("Select DTH Operator (Airtel / DishTV / Reliance / TATASky)");
			String type=scanner.nextLine();
			obj.setdthOperator(type);
			
			System.out.println("Enter Registered Consumer No.:");
			String consumerNo=scanner.nextLine();
			obj.setconsumerNo(consumerNo);
			
			System.out.println("Select Plan(Monthly / Quaterly / Half yearly / Annual)");
			String rechargePlan=scanner.nextLine();
			obj.setrechargePlan(rechargePlan);														// DIFFERENT DETAILS OF RECHARGE
			
			System.out.println("Enter Amount (Rs)");
			int amount=scanner.nextInt();
			obj.setAmount(amount);
			
			if(RdV.validateDetails(obj)) 
			{
				System.out.println("Successful Recharge. Transaction ID: "+obj.getTransaction_ID());		// CONFIRMATION OF RECHARGE
				
			}
			else
			{
				System.out.println("Failed to recharge.");												// DECLINATION OF RECHARGE 
			}
	
		
		
	}

}
